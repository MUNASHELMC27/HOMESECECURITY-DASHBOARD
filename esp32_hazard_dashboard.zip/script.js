
const client = mqtt.connect('wss://broker.hivemq.com:8884/mqtt');

client.on('connect', () => {
  console.log('MQTT Connected');
  document.getElementById('mqttStatus').innerHTML = 'MQTT: <span class="status-icon">✅</span> Connected';
  client.subscribe('esp32/hazard');
});

const ctx = document.getElementById('hazardChart').getContext('2d');
const hazardChart = new Chart(ctx, {
  type: 'line',
  data: {
    labels: [],
    datasets: [{
      label: 'Hazard Value',
      data: [],
      fill: false,
      borderColor: '#00bcd4',
      tension: 0.3
    }]
  },
  options: {
    responsive: true,
    animation: false,
    scales: {
      x: {
        title: { display: true, text: 'Time' },
      },
      y: {
        beginAtZero: true,
        title: { display: true, text: 'Value' },
      }
    }
  }
});

function updateStatus(gas, flame, value) {
  document.getElementById('gasStatus').innerHTML = 'Gas Sensor: <span class="status-icon">✅</span> ' + (gas === 'danger' ? 'Danger' : 'Safe');
  document.getElementById('flameStatus').innerHTML = 'Flame Sensor: <span class="status-icon">✅</span> ' + (flame === 'detected' ? 'Flame Detected' : 'No flame detected');
}

client.on('message', (topic, message) => {
  const msg = message.toString();
  const time = new Date().toLocaleTimeString();

  let value = 0;
  let gas = "safe";
  let flame = "none";

  try {
    const data = JSON.parse(msg);
    value = parseFloat(data.value);
    gas = data.gas || "safe";
    flame = data.flame || "none";
  } catch (err) {
    console.warn("Non-JSON message received:", msg);
    value = parseFloat(msg);
  }

  hazardChart.data.labels.push(time);
  hazardChart.data.datasets[0].data.push(value);
  if (hazardChart.data.labels.length > 20) {
    hazardChart.data.labels.shift();
    hazardChart.data.datasets[0].data.shift();
  }
  hazardChart.update();

  updateStatus(gas, flame, value);
  document.getElementById('lastUpdate').textContent = `Last update: ${time}`;
});
